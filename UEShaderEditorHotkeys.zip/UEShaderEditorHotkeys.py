bl_info = {
    "name": "UE Shader Hotkeys",
    "author": "Tekimus",
    "version": (1, 0),
    "blender": (2, 80, 0),
    "description": "Adds the hotkeys from Unreal Engine's Material Editor to Blender's Shader Editor for your convenience.",
}



import bpy





def GetMousePosition(context, event) :
    mouse_x = event.mouse_region_x
    mouse_y = event.mouse_region_y
    mouse_position = context.region.view2d.region_to_view(mouse_x, mouse_y)
    return mouse_position



# Const Nodes
class AddValueNode(bpy.types.Operator) :
    bl_idname = "node.add_value_node"
    bl_label = "Add Value Node"
    
    def invoke(self, context, event) :
        area = context.area
        if area.type == "NODE_EDITOR" :
            space = context.space_data
            node_tree = space.node_tree
            
            if not node_tree :
                return {'CANCELLED'}
            
            mousePos = GetMousePosition(context, event)
            
            new_node = node_tree.nodes.new(type='ShaderNodeValue')
            new_node.location = (mousePos[0], mousePos[1])
            
            return {'FINISHED'}
        else :
            return {'CANCELLED'}

class AddRGBNode(bpy.types.Operator) :
    bl_idname = "node.add_rgb_node"
    bl_label = "Add RGB Node"
    
    def invoke(self, context, event) :
        area = context.area
        if area.type == "NODE_EDITOR" :
            space = context.space_data
            node_tree = space.node_tree
            
            if not node_tree :
                return {'CANCELLED'}
            
            mousePos = GetMousePosition(context, event)
            
            new_node = node_tree.nodes.new(type='ShaderNodeRGB')
            new_node.location = (mousePos[0], mousePos[1])
            
            return {'FINISHED'}
        else :
            return {'CANCELLED'}


# Math Nodes
class AddMultiplyNode(bpy.types.Operator) :
    bl_idname = "node.add_multiply_node"
    bl_label = "Add Multiply Node"
    
    def invoke(self, context, event) :
        area = context.area
        if area.type == "NODE_EDITOR" :
            space = context.space_data
            node_tree = space.node_tree
            
            if not node_tree :
                return {'CANCELLED'}
            
            mousePos = GetMousePosition(context, event)
            
            new_node = node_tree.nodes.new(type='ShaderNodeMath')
            new_node.operation =  "MULTIPLY"
            new_node.location = (mousePos[0], mousePos[1])
            
            return {'FINISHED'}
        else :
            return {'CANCELLED'}

class AddAddNode(bpy.types.Operator) :
    bl_idname = "node.add_add_node"
    bl_label = "Add Add Node"
    
    def invoke(self, context, event) :
        area = context.area
        if area.type == "NODE_EDITOR" :
            space = context.space_data
            node_tree = space.node_tree
            
            if not node_tree :
                return {'CANCELLED'}
            
            mousePos = GetMousePosition(context, event)
            
            new_node = node_tree.nodes.new(type='ShaderNodeMath')
            new_node.operation =  "ADD"
            new_node.location = (mousePos[0], mousePos[1])
            
            return {'FINISHED'}
        else :
            return {'CANCELLED'}

class AddSubtractNode(bpy.types.Operator) :
    bl_idname = "node.add_subtract_node"
    bl_label = "Add Subtract Node"
    
    def invoke(self, context, event) :
        area = context.area
        if area.type == "NODE_EDITOR" :
            space = context.space_data
            node_tree = space.node_tree
            
            if not node_tree :
                return {'CANCELLED'}
            
            mousePos = GetMousePosition(context, event)
            
            new_node = node_tree.nodes.new(type='ShaderNodeMath')
            new_node.operation =  "SUBTRACT"
            new_node.location = (mousePos[0], mousePos[1])
            
            return {'FINISHED'}
        else :
            return {'CANCELLED'}

class AddDivideNode(bpy.types.Operator) :
    bl_idname = "node.add_divide_node"
    bl_label = "Add Divide Node"
    
    def invoke(self, context, event) :
        area = context.area
        if area.type == "NODE_EDITOR" :
            space = context.space_data
            node_tree = space.node_tree
            
            if not node_tree :
                return {'CANCELLED'}
            
            mousePos = GetMousePosition(context, event)
            
            new_node = node_tree.nodes.new(type='ShaderNodeMath')
            new_node.operation =  "DIVIDE"
            new_node.location = (mousePos[0], mousePos[1])
            
            return {'FINISHED'}
        else :
            return {'CANCELLED'}

class AddPowerNode(bpy.types.Operator) :
    bl_idname = "node.add_power_node"
    bl_label = "Add Power Node"
    
    def invoke(self, context, event) :
        area = context.area
        if area.type == "NODE_EDITOR" :
            space = context.space_data
            node_tree = space.node_tree
            
            if not node_tree :
                return {'CANCELLED'}
            
            mousePos = GetMousePosition(context, event)
            
            new_node = node_tree.nodes.new(type='ShaderNodeMath')
            new_node.operation =  "POWER"
            new_node.location = (mousePos[0], mousePos[1])
            
            return {'FINISHED'}
        else :
            return {'CANCELLED'}


# Other Nodes
class AddOneMinusNode(bpy.types.Operator) :
    bl_idname = "node.add_oneminus_node"
    bl_label = "Add One Minus Node"
    
    def invoke(self, context, event) :
        area = context.area
        if area.type == "NODE_EDITOR" :
            space = context.space_data
            node_tree = space.node_tree
            
            if not node_tree :
                return {'CANCELLED'}
            
            mousePos = GetMousePosition(context, event)
            
            new_node = node_tree.nodes.new(type='ShaderNodeMath')
            new_node.operation =  "SUBTRACT"
            new_node.inputs[0].default_value = 1.0
            new_node.inputs[1].default_value = 0.0
            new_node.location = (mousePos[0], mousePos[1])
            
            return {'FINISHED'}
        else :
            return {'CANCELLED'}

class AddImageTextureNode(bpy.types.Operator) :
    bl_idname = "node.add_imagetexture_node"
    bl_label = "Add Image Texture Node"
    
    def invoke(self, context, event) :
        area = context.area
        if area.type == "NODE_EDITOR" :
            space = context.space_data
            node_tree = space.node_tree
            
            if not node_tree :
                return {'CANCELLED'}
            
            mousePos = GetMousePosition(context, event)
            
            new_node = node_tree.nodes.new(type='ShaderNodeTexImage')
            new_node.location = (mousePos[0], mousePos[1])
            
            return {'FINISHED'}
        else :
            return {'CANCELLED'}

class AddMixNode(bpy.types.Operator) :
    bl_idname = "node.add_mix_node"
    bl_label = "Add Mix Node"
    
    def invoke(self, context, event) :
        area = context.area
        if area.type == "NODE_EDITOR" :
            space = context.space_data
            node_tree = space.node_tree
            
            if not node_tree :
                return {'CANCELLED'}
            
            mousePos = GetMousePosition(context, event)
            
            new_node = node_tree.nodes.new(type='ShaderNodeMix')
            new_node.location = (mousePos[0], mousePos[1])
            
            return {'FINISHED'}
        else :
            return {'CANCELLED'}





from bpy.utils import register_class, unregister_class

_classes = [
    AddValueNode,
    AddRGBNode,
    AddMultiplyNode,
    AddAddNode,
    AddSubtractNode,
    AddDivideNode,
    AddPowerNode,
    AddOneMinusNode,
    AddImageTextureNode,
    AddMixNode
]

keymap_items = [

]



def register():
    for cls in _classes : 
        register_class(cls)
        
    wm = bpy.context.window_manager
    km = wm.keyconfigs.addon.keymaps.new(name='Node Editor', space_type='NODE_EDITOR')
    
    keymap_items.append(km.keymap_items.new(AddValueNode.bl_idname, 'ONE', 'PRESS'))
    keymap_items.append(km.keymap_items.new(AddRGBNode.bl_idname, 'THREE', 'PRESS'))
    keymap_items.append(km.keymap_items.new(AddMultiplyNode.bl_idname, 'M', 'PRESS'))
    keymap_items.append(km.keymap_items.new(AddAddNode.bl_idname, 'A', 'PRESS'))
    keymap_items.append(km.keymap_items.new(AddSubtractNode.bl_idname, 'S', 'PRESS'))
    keymap_items.append(km.keymap_items.new(AddDivideNode.bl_idname, 'D', 'PRESS'))
    keymap_items.append(km.keymap_items.new(AddPowerNode.bl_idname, 'E', 'PRESS'))
    keymap_items.append(km.keymap_items.new(AddOneMinusNode.bl_idname, 'O', 'PRESS'))
    keymap_items.append(km.keymap_items.new(AddImageTextureNode.bl_idname, 'I', 'PRESS'))
    keymap_items.append(km.keymap_items.new(AddMixNode.bl_idname, 'L', 'PRESS'))



def unregister():
    for cls in _classes : 
        unregister_class(cls)
        
    wm = bpy.context.window_manager
    km = wm.keyconfigs.addon.keymaps.get('Node Editor')
    
    if km :
        for kmi in keymap_items :
            km.keymap_items.remove(kmi)
        keymap_items.clear()



if __name__ == "__main__":
    register()